/**
 * Created by oscaralmgren on 06/05/15.
 */

/** Pre-loading images */
if (document.images) {
	var img = new Image();
	img.src = "img/tileBackground.png";
}
/*
if (document.images) {
	for (var i=1; i<16; i++) {
		var img = new Image();
		img.src = "img/items/ref" + i + "0.png";
	}
}
*/
function clearLtpa(){
	document.getElementById("logoutButton").style.visibility = 'hidden';
	document.cookie = "LtpaToken2=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
	window.location = "https://catalogm.mybluemix.net";
}

var forceSSL = function () {
    if (window.location.protocol !== 'https:') {
        window.location.href = window.location.href.replace(/^http/, 'https');
    }
};
forceSSL();

var catalogApp = angular.module("catalogApp", ["ngRoute", "ngMaterial", "catalogController", "orderController", "loginController"]);

catalogApp.config(function($routeProvider) {
    $routeProvider

        .when("/order/:itemId", {
            templateUrl  : "pages/order.html",
            controller   : "orderController"
        })

        .when("/catalog", {
            templateUrl  : "pages/catalog.html",
            controller   : "catalogController as vm"
        })

        .when("/login", {
            templateUrl  : "pages/login.html",
            controller   : "loginController"
        })
        
	.otherwise({
            redirectTo    : "/catalog"
        });
})

.run(function($rootScope,$cacheFactory) {
    $rootScope.$on( "$routeChangeStart", function() {
      if (document.cookie) {
      	document.getElementById("logoutButton").style.visibility = 'visible';
      } else {
      	document.getElementById("logoutButton").style.visibility = 'hidden';
      }
    });
    var cache = $cacheFactory('imagesCache');
});