/**
 * Created by oscaralmgren on 07/05/15.
 */
angular
    .module('catalogController', ['ngMaterial', 'ngResource'])
    .controller('catalogController', ['$scope', '$location', 'getCatalog', '$resource', '$cacheFactory', function($scope, $location, getCatalog, $resource, $cacheFactory) {
        forceSSL();
        var vm = this;
        vm.tiles = [];
        $scope.startRef = "0";
        
        getCatalog.save({ltpa:document.cookie, startRef: $scope.startRef}, retrieveCatalog);
        
        function retrieveCatalog (data) {
		    if (data.LoginForm) {
		    	$location.url('/login');
		    	document.getElementById("logoutButton").style.visibility = 'hidden';
		    	return;
		    }
		    
            $scope.catalog = data.DFH0XCMNOperationResponse.ca_inquire_request.ca_cat_item;
            $scope.startRef = data.DFH0XCMNOperationResponse.ca_inquire_request.ca_last_item_ref + 1;
            $scope.itemCount = data.DFH0XCMNOperationResponse.ca_inquire_request.ca_item_count;

            buildGridModel({
                icon : "ref",
                title: "",
                cost: "€",
                background: "",
                stock: "",
                ca_item_ref: ""
            });
            
            if ($scope.itemCount!=0) {
            	getCatalog.save({ltpa:document.cookie, startRef: $scope.startRef}, retrieveCatalog);
            }
            function buildGridModel(tileTmpl){
                var it;
                var results = [ ];
                for (var j=0; j<$scope.itemCount; j++){
                    it = angular.extend({},tileTmpl);
                    //it.icon  = it.icon + $scope.catalog[j].ca_item_ref + ".png";
                    it.title = $scope.catalog[j].ca_description;
                    if (it.title.indexOf('$$') > -1){
                    	it.title = it.title.replace('$$','10');
                    }
                    it.cost = it.cost + $scope.catalog[j].ca_cost.replace(/^[0]+/g,"");
                    it.stock = $scope.catalog[j].in_stock;
                    if (it.stock == 0){
                    	it.background = "noStock";
                    } else {
                    	it.background = "inStock";
                    }
                    
                    it.span  = { row : 1, col : 1 };
                    it.ca_item_ref = $scope.catalog[j].ca_item_ref;
                    /*
                    var colorChoice = j%8-2*Math.floor(j/8);
                    if (colorChoice < 0){
                    	colorChoice += 8;
                    }
                    switch(colorChoice){
                        case 0: it.background += " red";           break;
                        case 1: it.background += " green";         break;
                        case 2: it.background += " deepBlue";      break;
                        case 3: it.background += " yellow";        break;
                        case 4: it.background += " purple";        break;
                        case 5: it.background += " darkBlue";      break;
                        case 6: it.background += " orange";        break;
                        case 7: it.background += " pink";          break;
                    }
                    */
                    retrieveImage(it);
                }
                
            }
            
            function retrieveImage(it) {
            	if (!$cacheFactory.get('imagesCache').get(it.ca_item_ref)) {
            		$resource('catalogm/v1/apps/1e78b548-194b-4346-b094-f6d6e52978fa/image/:itemRef',
            				{itemRef: '@itemRef'},{'save': {method:'POST', isArray:true}})
            		.save({ltpa:document.cookie, itemRef: it.ca_item_ref},function(data) {
            			it.icon = data[0].image;
            			$cacheFactory.get('imagesCache').put(it.ca_item_ref,data[0].image);
            			vm.tiles.push(it);
            		});
            	} else {
            		it.icon = $cacheFactory.get('imagesCache').get(it.ca_item_ref);
            		vm.tiles.push(it);
            	}
            }
        };
        
        $scope.goToItem = function(tile) {
            $location.url('/order/' + tile.ca_item_ref);
        };
    }])

    .factory('getCatalog', ['$resource', function($resource){
    		return $resource('catalogm/v1/apps/1e78b548-194b-4346-b094-f6d6e52978fa/catalog');
    }]);
