/**
 * Created by oscaralmgren on 07/05/15.
 */
angular
    .module('loginController', ['ngMaterial', 'ngResource'])
    .controller('loginController', ['$scope', '$location', 'login', function($scope, $location, login) {
	forceSSL();
	
	$scope.loginAction = function() {
		$scope.errorMessage = "";
		$scope.creds = {username:$scope.username, password:$scope.password};
        	login.save($scope.creds, function(data){
			if (data.text.match("here</a>")) {
				for (var i = 0; i < data.cookies.length; i++) {
					if (data.cookies[i].match(/LtpaToken2/)){
						var expDate = new Date();
						expDate.setHours ( expDate.getHours() + 1 );
						document.cookie = data.cookies[i] + "; expires=" + expDate.toUTCString();
						document.getElementById("logoutButton").style.visibility = 'visible';
						break;
					}
				}
				$location.url('/catalog');
			} else {
				$scope.errorMessage = "Incorrect login";
				document.getElementById("logoutButton").style.visibility = 'hidden';
			}
		});	
	};
    }])

    .factory('login', ['$resource', function($resource){
        return $resource('catalogm/v1/apps/1e78b548-194b-4346-b094-f6d6e52978fa/login');
    }]);
