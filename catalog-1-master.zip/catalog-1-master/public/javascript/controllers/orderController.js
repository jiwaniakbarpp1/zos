/**
 * Created by oscaralmgren on 07/05/15.
 */


angular
    .module('orderController', ['ngMaterial', 'ngMessages', 'ngResource'])

    .controller('orderController', ['$scope', '$routeParams', '$location', 'getSingle', 'placeOrder'
                                    , 'validateAddress', 'sendConfirmation','$mdDialog', '$cacheFactory', '$resource',
        function($scope, $routeParams, $location, getSingle, placeOrder, validateAddress, sendConfirmation, $mdDialog, $cacheFactory, $resource) {
            forceSSL();
            
            $scope.alert;
            $scope.validatedAddress;

            if (!$cacheFactory.get('imagesCache').get($routeParams.itemId)) {
        		$resource('catalogm/v1/apps/1e78b548-194b-4346-b094-f6d6e52978fa/image/:itemRef',
        				{itemRef: '@itemRef'},{'save': {method:'POST', isArray:true}})
        		.save({ltpa:document.cookie, itemRef: $routeParams.itemId},function(data) {
        			if (data.LoginForm) {
        				$location.url('/login');
        				document.getElementById("logoutButton").style.visibility = 'hidden';
        				return;
        			}
        			$scope.itemImage = data[0].image;
        			$cacheFactory.get('imagesCache').put($routeParams.itemId,data[0].image);
        		});
        	} else {
        		$scope.itemImage = $cacheFactory.get('imagesCache').get($routeParams.itemId);
        	}
            
            $scope.cancelOrder = function() {
                $location.url('/catalog');
            };

            $scope.showConfirmation = function() {
                $mdDialog.show({
                    controller: dialogController,
                    templateUrl: 'pages/conf-dialog.html',
                    locals: { params : {
                        user: $scope.user,
                        order: $scope.order,
                        validatedAddress: $scope.validatedAddress,
                        cost: $scope.cost,
                        emailMessage: $scope.emailMessage
                    }
                    }
                });
            };
            
            $scope.showAddressValidation = function(error) {
            	function handler(resp) {
                	if (resp=="KO"){
   
                		$scope.validatedAddress.AddressBlock1 = $scope.user.address;
                		$scope.validatedAddress.AddressBlock2 = $scope.user.city + " " + $scope.user.state + " " + $scope.user.postalCode;
                		$scope.validatedAddress.AddressBlock3 = $scope.user.country;
 
                	}
                	$scope.order.ltpa = document.cookie;
                	placeOrder.save($scope.order, function(data) {
                		if (data.LoginForm) {
							$location.url('/login');
							document.getElementById("logoutButton").style.visibility = 'hidden';
							return;
		  	             }
                			// on response
                        	var resp = data.DFH0XCMNOperationResponse;

        	                $scope.order.ca_response_message = resp.ca_response_message;
                	        $scope.order.ca_request_id = resp.ca_request_id;
                        	$scope.order.ca_order_request = resp.ca_order_request; // item_ref, charge_dept, userid, quantity
                    	
                		$scope.confirmationEmail = {
                            	email: $scope.user.email,
                            	addressBlocks: JSON.stringify($scope.validatedAddress),
                         	   	order: JSON.stringify($scope.order)
                		};
                		sendConfirmation.save($scope.confirmationEmail, function (response) {
	                    		if (response.message === "success") {
	                    			$scope.emailMessage = "A confirmation email has been sent to " + $scope.user.email + ".";
	                    		} else {
	                    			$scope.emailMessage = "An error occurred while sending the confirmation email.";	
	                    		}
	                    		$scope.showConfirmation(); // show confirmation dialog
	                	});
	                	// si le sendgrid ne fonctionne pas !
	                	//$scope.emailMessage = "No email service.";
	                	//$scope.showConfirmation();
                	});
         
                }
            	if (!error) {
	            	$mdDialog.show({
	                    controller: dialogAddressController,
	                    templateUrl: 'pages/conf-address-dialog.html',
	                    locals: { params : {
	                        validatedAddress: $scope.validatedAddress
	                    }}
	                }).then(handler);
            	} else {
            		handler("KO");
            	}
            };

            $scope.user = {
                email: '',
                firstName: '',
                lastName: '' ,
                address: '1600 Amphitheatre Pkwy' ,
                city: 'Mountain View' ,
                state: 'CA' ,
                orderInstructions: 'Order instructions',
                postalCode : '94043',
                country : "USA"
            };

            $scope.order = {
                itemID : $routeParams.itemId
            };


            var reqBody = {itemID: $scope.order.itemID, ltpa: document.cookie};
            getSingle.save({}, reqBody, function(data){
				if (data.LoginForm) {
					$location.url('/login');
					document.getElementById("logoutButton").style.visibility = 'hidden';
					return;
		  	    }
                $scope.order = data.DFH0XCMNOperationResponse.ca_inquire_single.ca_single_item;
                $scope.order.ca_sngl_cost = $scope.order.ca_sngl_cost.replace(/^[0]+/g,"");
                $scope.order.itemID = $scope.order.ca_sngl_item_ref;
                
                if ($scope.order.ca_sngl_description.indexOf('$$') > -1){
                	$scope.order.ca_sngl_description = $scope.order.ca_sngl_description.replace('$$','10');
                }
                if ($scope.order.in_sngl_stock=="0"){
                	$scope.order.nb = 0;
                	document.getElementById("inputQuantity").disabled = true;
                	document.getElementById("submitButton").disabled = true; 
                } else {
                	$scope.order.nb = 1;
                }
                $scope.cost = '€' + ($scope.order.nb * parseFloat($scope.order.ca_sngl_cost)).toFixed(2);
            });

            $scope.orderItem = function() {
                var orderBody = $scope.order;
                //console.log(orderBody);
                
                validateAddress.save($scope.user, function (data) {
                    if (data.Status == "OK") {
                        $scope.validatedAddress = data.AddressBlocks;
                        $scope.validatedAddress.user = $scope.user.firstName + " " + $scope.user.lastName;

                        $scope.showAddressValidation(false);
                    } else if (data.Status == "ERROR"){
                    	$scope.validatedAddress = {user: "user"};
                        $scope.validatedAddress.user = $scope.user.firstName + " " + $scope.user.lastName;
                        
                        $scope.showAddressValidation(true);
                    } else if (data.Status == "FAIL") {
                    	alert(data.Message);
                    } else {
                    	alert("Pb Validate Address : " + JSON.stringify(data));
                    	$scope.validatedAddress = {user: "user"};
                        $scope.validatedAddress.user = $scope.user.firstName + " " + $scope.user.lastName;
                        
                    	$scope.showAddressValidation(true);
                    }
                });
            };
        }])

    .config( function($mdThemingProvider){
        // Configure a dark theme with primary foreground yellow
        $mdThemingProvider.theme('docs-dark', 'default')
            .primaryPalette('yellow')
            .dark();
    })

    .factory('getSingle', ['$resource', function($resource){
        return $resource('catalogm/v1/apps/1e78b548-194b-4346-b094-f6d6e52978fa/single');
    }])

    .factory('placeOrder', ['$resource', function($resource){
        return $resource('catalogm/v1/apps/1e78b548-194b-4346-b094-f6d6e52978fa/order');
    }])

    .factory('validateAddress', ['$resource', function($resource){
        return $resource('catalogm/v1/apps/1e78b548-194b-4346-b094-f6d6e52978fa/validateAddress');
    }])

    .factory('sendConfirmation', ['$resource', function($resource){
        return $resource('catalogm/v1/apps/1e78b548-194b-4346-b094-f6d6e52978fa/sendConfirmation');
    }])
    
    .directive('costCalculator', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                scope.$watch(attrs.ngModel, function (v) {
                    scope.cost = '€' + (scope.order.nb * parseFloat(scope.order.ca_sngl_cost)).toFixed(2);
                });
            }
        };
    });

function dialogController($scope, $location, $mdDialog, params) {
    $scope.user = params.user;
    $scope.order = params.order;
    $scope.validatedAddress = params.validatedAddress;
    $scope.cost = params.cost;
    $scope.emailMessage = params.emailMessage;

    $scope.goToCatalog = function() {
        $mdDialog.hide();
        $location.url('/catalog');
    }
}

function dialogAddressController($scope, $mdDialog,params) {
    $scope.validatedAddress = params.validatedAddress;
    $scope.ignoreSendGrid = function() {
        $mdDialog.hide("KO");
    };
    $scope.placeOrder = function() {
    	$mdDialog.hide("OK");
    };
    $scope.cancel = function() {
    	$mdDialog.cancel();
    };
}
